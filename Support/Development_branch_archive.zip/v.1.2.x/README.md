# Standard Tracker Application

In this repository, only the standard version of the Tracker application is stored. 
Additional information and issue tracker can be found at 
https://bitbucket.org/neurotarteam/standard-tracker-application. 
For more information, contact us at info@neurotar.com.

```
Mobile HomeCage motion tracking software.
Current version 1.2.0.6

Mobile HomeCage motion tracking software for recording mouse activity
in the Mobile HomeCage devices.
Copyright 2018 Neurotar Oy Ltd

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published
by the Free Software Foundation, either version 3 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.
```